def main():
    print('Hi from my_hexacopter.')


if __name__ == '__main__':
    main()
